#!/usr/bin/env python3
"""Rebuild the embedded source mirror used by self_index after install.

The APK cannot read the repository, so a trimmed .kt snapshot is shipped in assets.
CI runs this before assembling; the app extracts it into the evolution mirror on first
launch. Keep it source-only: no resources, no secrets, no build output.
"""
import pathlib
import tarfile

ROOT = pathlib.Path(__file__).resolve().parents[1]
MODULES = [
    "agent-runtime", "app", "business", "libs", "ui-kit", "accessibility",
    "store", "remote-view", "xsettings", "evolution",
]
OUT = ROOT / "app/src/main/assets/evolution/src.tar.gz"
SKIP_PARTS = {"build", "build-local", ".gradle", ".git", "node_modules", "generated"}


def sources():
    for module in MODULES:
        base = ROOT / module
        if not base.exists():
            continue
        for path in base.rglob("*.kt"):
            if not path.is_file():
                continue
            relative = path.relative_to(ROOT)
            if any(part in SKIP_PARTS for part in relative.parts):
                continue
            yield relative


def main():
    files = sorted(set(sources()))
    OUT.parent.mkdir(parents=True, exist_ok=True)
    with tarfile.open(OUT, "w:gz") as archive:
        for relative in files:
            archive.add(ROOT / relative, arcname="zafiro-main/" + relative.as_posix())
    print(f"embedded {len(files)} Kotlin files -> {OUT} ({OUT.stat().st_size} bytes)")


if __name__ == "__main__":
    main()
